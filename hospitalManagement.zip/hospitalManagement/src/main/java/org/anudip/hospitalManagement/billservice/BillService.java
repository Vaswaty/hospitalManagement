package org.anudip.hospitalManagement.billservice;

public class BillService {

}