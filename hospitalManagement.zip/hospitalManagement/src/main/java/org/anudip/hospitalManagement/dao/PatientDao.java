package org.anudip.hospitalManagement.dao;

import java.util.List;

import org.anudip.hospitalManagement.bean.Patient;

public interface PatientDao {
	public void save(Patient patient);
	public List<Patient> displayAllPatients();
	public Patient findSinglePatient(Integer patientNumber);
	public Integer generatePatientId();

}
