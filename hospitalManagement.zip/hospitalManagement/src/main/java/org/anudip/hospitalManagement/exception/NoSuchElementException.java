package org.anudip.hospitalManagement.exception;

public class NoSuchElementException extends RuntimeException{

}
