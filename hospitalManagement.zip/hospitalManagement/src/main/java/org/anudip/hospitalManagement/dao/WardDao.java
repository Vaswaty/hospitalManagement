package org.anudip.hospitalManagement.dao;

import java.util.List;

import org.anudip.hospitalManagement.bean.Ward;


public interface WardDao {
	public void save(Ward ward);
	public List<Ward> displayAllWard();
	public Ward findSingleWard(String Id);
	public String generateWardId();
	

}
