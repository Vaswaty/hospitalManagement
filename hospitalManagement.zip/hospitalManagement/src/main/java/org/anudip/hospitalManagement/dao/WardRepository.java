package org.anudip.hospitalManagement.dao;

import org.springframework.stereotype.Repository;
import org.anudip.hospitalManagement.bean.Ward;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
@Repository
public interface WardRepository extends JpaRepository<Ward, String> {
	@Query("select max(wardId) from Ward")
	 public String getCountId();

}
