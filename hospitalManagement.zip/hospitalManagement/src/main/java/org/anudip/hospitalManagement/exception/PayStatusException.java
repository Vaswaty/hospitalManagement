package org.anudip.hospitalManagement.exception;

public class PayStatusException extends RuntimeException{

}
