package org.anudip.hospitalManagement.dao;

import java.util.List;
import org.anudip.hospitalManagement.bean.Ward;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
@Repository
@Service
public class WardDaoImpl implements WardDao {
	@Autowired
	private WardRepository repository;


	@Override
	public void save(Ward ward) {
		repository.save(ward); 

	}

	@Override
	public List<Ward> displayAllWard() {
		return repository.findAll(); 
	}

	@Override
	public Ward findSingleWard(String id) {
		return repository.findById(id).get(); 
	}

	@Override
	public String generateWardId() {
		String id="W101";
		int x=Integer.parseInt(id.substring(1));
		x++;
		System.out.println(x);
		id="W"+x;
		System.out.println(id);
		return id;
		
		

	}

	

}
